import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accomplish',
  templateUrl: './accomplish.component.html',
  styleUrls: ['./accomplish.component.css']
})
export class AccomplishComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
